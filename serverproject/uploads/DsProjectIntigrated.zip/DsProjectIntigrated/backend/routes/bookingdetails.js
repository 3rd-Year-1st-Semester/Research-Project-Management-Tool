const router= require("express").Router();
let BookingDetails =require("../models/bookingdetails");

router.route("/add").post((req,res)=>{
    const userId= req.body.userId;
    const hallId= req.body.hallId;
    const movieId= req.body.movieId;
    const seatNo = req.body.seatNo;
    const totalPrice= Number(req.body.totalPrice);
    const time = req.body.time;
    const Date=req.body.Date;
    
  
   
    const newbookingdetails = new BookingDetails({
        userId,
        hallId,
        movieId,
        seatNo,
        totalPrice,
        time,
        Date,
        
    })
    newbookingdetails.save().then(()=>{
        res.json("BookingDetails Added")
    }).catch((err)=>{
        console.log(err);
    })
})

router.route("/").get((req,res)=>{
    BookingDetails.find().then((BookingDetails)=>{
        res.json(BookingDetails)
    }).catch((err)=>{
        console.log(err)
    })
})
router.route('/update/:id').put((req, res, next) => {
    BookingDetails.findByIdAndUpdate(req.params.id, {
      $set: req.body
    }, (error, data) => {
      if (error) {
        return next(error);
        console.log(error)
      } else {
        res.json(data)
        console.log('BookingDetails updated successfully !')
      }
    })
  })

router.route("/delete/:id").delete(async(req, res)=>{
    let accId=req.params.id;

    await BookingDetails.findByIdAndDelete(accId)
    .then(()=>{
        res.status(200).send({status:" BookingDetails deleted"});
    }).catch((err)=>{
        console.log(err.message);
        res.status(500).send({status:"Error with delete",error:err.message});
    })
})


router.route('/get/:id').get((req, res) => {
   BookingDetails.findById(req.params.id, (error, data) => {
      if (error) {
        return next(error)
      } else {
        res.json(data)
      }
    })
  })  
module.exports=router;
