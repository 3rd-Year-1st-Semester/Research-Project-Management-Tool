const express = require('express');
const users = express.Router();//create application endpoints
const cors = require('cors');//share resources
const jwt = require('jsonwebtoken');//sequre transfer
const bcrypt = require('bcrypt');//sequre password encrypt
const User = require('../models/User');
const { hash } = require("bcrypt");
const { json } = require('body-parser');
const { update } = require('../models/User');


users.use(cors());

process.env.SECRET_KEY = 'secret';// Use secret key
users.post('/register', (req, res) => {

    const today = new Date();
    const userData = new User({

        first_name: req.body.first_name,
        last_name: req.body.last_name,
        age: req.body.age,
        phone_number: req.body.phone_number,
        address: req.body.address,
        email: req.body.email,
        password: req.body.password,
        user_type: req.body.user_type,
        created: today,

    });

    //find user

    User.findOne({
        email: req.body.email
    })
        .then(user => {
            if (!user) {
                bcrypt.hash(req.body.password, 10, (err, hash) => {
                    userData.password = hash
                    userData.user_type = "user";
                    User.create(userData).then(user => {
                        res.json({ status: user.email + " registered" })
                    })
                        .catch(err => {
                            res.send("error" + err);
                        })

                })

            } else {

                res.json({ error: "User already registered" })

            }
        })
        .catch(err => {
            res.send("error" + err);
        })
})

users.post('/login', (req, res) => {

    User.findOne({
        email: req.body.email
    })
        .then(user => {

            if (user) {
                if (bcrypt.compareSync(req.body.password, user.password)) {


                    const payload = {

                        _id: user._id,
                        first_name: user.first_name,
                        last_name: user.last_name,
                        age: user.age,
                        phone_number: user.phone_number,
                        address: user.address,
                        email: user.email,
                        user_type: user.user_type

                    }
                    let token = jwt.sign(payload, process.env.SECRET_KEY, {
                        expiresIn: 1440
                    })
                    res.send(token)


                } else {
                    res.json({ error: "User does not exsist in the system" })
                }

            } else {

                res.json({ error: "User does not exsist in the system" })
            }

        })
        .catch(err => {
            res.send("error" + err)
        })
})

users.get('/profile', (req, res) => {

    var decoded = jwt.verify(req.headers['authorization'], process.env.SECRET_KEY)

    User.findOne({

        _id: decoded._id
    })
        .then(user => {
            if (user) {
                res.json(user)
            } else {
                res.send("User does not exist");
            }

        })
        .catch(err => {
            res.send("Error" + err);
        })
});

users.get("/", ((req, res) => {

    User.find({
        user_type: "user"
    })
        .then((data) => {
            if (data) {
                res.json(data);
            }
        })
        .catch((err) => {
            console.log(err);
        })

}));

users.get("/:id", ((req, res) => {

    const id = req.params.id;

    User.findById(id)
        .then((data) => {
            res.json(data);
        })
        .catch((err) => {
            console.log(err);
        }
        )

}));

users.delete("/delete/:id", ((req, res) => {
    var id = req.params.id;

    User.findByIdAndDelete(id).then(() => {
        res.json("User deleted successfully");
    }).catch((err) => {
        console.log("Error : " + err);
    })
}));


users.route("/update/:id").put((req, res) => {

    let id = req.params.id

    let first_name = req.body.first_name;
    let last_name = req.body.last_name;
    let age = req.body.age;
    let phone_number = req.body.phone_number;
    let address = req.body.address;
    let email = req.body.email;
    let password = req.body.password;

    const updateObj = {
        first_name, last_name, age, phone_number, address, email, password
    };

    User.findByIdAndUpdate(id, updateObj)
        .then(() => {
            res.json("Update Successfully")

        }).catch((err) => {
            console.log(err);
        })

})

module.exports = users;

//post
//http://localhost:5000/users/register

//post
//http://localhost:5000/users/login