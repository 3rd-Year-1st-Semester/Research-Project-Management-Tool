const mongoose= require('mongoose');
const Schema=mongoose.Schema;
const bookingdetailSchema=new Schema({
    userId:{
        type:String,
        required:true
    },
    hallId:{
        type:String,
        required:true
    },
    movieId:{
        type:String,
        required:true
    },
   
    seatNo:{
        type:String,
        required:true
    },
    totalPrice:{
        type:Number,
        required:true
    },
    time:{
        type:String,
        required:true
    },
    Date:{
        type:String,
        required:true
    },
    
})
const bookingdetails=mongoose.model("bookingdetails",bookingdetailSchema);
module.exports=bookingdetails;