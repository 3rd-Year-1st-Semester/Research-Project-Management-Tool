const express = require("express");
const cors = require("cors");
const bp = require("body-parser");
const mongoose = require("mongoose");

require("dotenv/config");

//Import routes
//nipuna
const bookingdetailsRouter= require("./routes/bookingdetails");

//sachini
var Users = require('./routes/Users');
var Admins = require('./routes/Admins');

//gayashan
let movie = require('./routes/movies');

//Ashan
const theaterRouter = require('./routes/theaters');



///////////////////


const app = express();

const PORT = 8000 || process.env.PORT;
const MONGODB_URL = process.env.MONGODB_URL || "mongodb+srv://admin:admin@online-movie-reservatio.3tpce.mongodb.net/online-movie-reservation?retryWrites=true&w=majority"

app.use(bp.json());
app.use(cors());



mongoose.connect(MONGODB_URL, {
    useNewUrlParser: true
}).then(() => {
    console.log("MonogoDB connected!!");
}).catch((err) => {
    console.error(err);
});

//Routes

//nipuna
app.use("/bookingdetails",bookingdetailsRouter);

//sachini
app.use('/users', Users);
app.use('/admins', Admins);

//gayashan
app.use('/movie', movie);

//Ashan
app.use("/theater",theaterRouter);



//////////////////////////////

app.get("/", (req, res, next) => {
    res.send("<center><h1>Online movie Reservation Backend API</h1></center>");
    next();
    ;
})

app.listen(PORT, () => {
    console.log(`Server up and running on port ${PORT}`);
});