import axios from 'axios';

 const THEATER_API_BASE_URL = "http://localhost:8090/theater";

class TheaterService {

    getCustomer(){
        return axios.get(THEATER_API_BASE_URL);
    }

    createCustomer(theater){
        return axios.post(THEATER_API_BASE_URL, theater);
    }

    getCustomerById(theaterId){
        return axios.get(THEATER_API_BASE_URL + '/' + theaterId);
    }

    updateCustomer(theater, theaterId){
        return axios.put(THEATER_API_BASE_URL + '/' + theaterId, theater);
    }

    deleteCustomer(theaterId){
        return axios.delete(THEATER_API_BASE_URL + '/' + theaterId);
    }
}

export default new TheaterService()