import { Component } from "react";

class Landing extends Component {

    render() {

        return (

            <div className="container">
                <div className="jumbotron mt-5">
                    <div align="center" className="col-sm-8 mx-auto font-color-light">
                        <h1>Online Movie Booking System</h1>
                    </div>
                    <br />
                    <div align="center" className="col-sm-8 mx-auto">
                        <h1>Welcome to movie Booking</h1>
                    </div>
                </div>
            </div>

        );

    }
}

export default Landing;