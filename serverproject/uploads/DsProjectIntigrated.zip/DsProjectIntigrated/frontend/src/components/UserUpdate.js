import axios from "axios";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

export default function UserUpdate() {

    const { id } = useParams();

    const [user, setUser] = useState("");

    const updateUser = (e) => {
        e.preventDefault();

        axios.put(`/users/update/${id}`, user).then((res) => {

            alert(res.data);
            window.location.href = "/profile"

        }).catch((err) => {
            console.log(err);
        });
    }

    useEffect(() => {
        axios.get(`/users/${id}`)
            .then((res) => {
                console.log(res.data);
                setUser(res.data);
            })
            .catch((err) => {
                console.log(err);
            })
    }, [])

    const handleChange = event => {
        const { name, value } = event.target;
        setUser({ ...user, [name]: value });
    }

    return (
        <div className="container py-5 h-100">
            <div className="row d-flex justify-content-center align-items-center h-100">
                <div className="col">
                    <div className="card card-registration my-4">
                        <div className="row g-0">
                            <div className="col">
                                <form onSubmit={updateUser} className="form-group">

                                    <h3 className="mb-5 text-uppercase">Update</h3>

                                    <div className="form-outline">
                                        <input type="text" value={user.first_name} name="first_name" className="form-control-sm col-3" placeholder="Enter Firstname" onChange={handleChange} /><br />
                                        <label className="form-label" for="first_name">First name</label>
                                    </div>

                                    <div className="form-outline">
                                        <input type="text" value={user.last_name} name="last_name" className="form-control-sm col-3" placeholder="Enter Lastname" onChange={handleChange} /><br />
                                        <label className="form-label" for="last_name">Last name</label>
                                    </div>

                                    <div className="form-outline">
                                        <input type="text" value={user.age} name="age" className="form-control-sm col-3" placeholder="Enter Age" onChange={handleChange} /><br />
                                        <label className="form-label" for="age">Age</label>
                                    </div>

                                    <div className="form-outline">
                                        <input type="text" value={user.phone_number} name="phone_number" className="form-control-sm col-3" placeholder="Enter phonenumber" onChange={handleChange} /><br />
                                        <label className="form-label" for="phone_number">Phone Number</label>
                                    </div >


                                    <div className="form-outline mb-4">
                                        <input type="text" value={user.address} name="address" className="form-control-sm col-3" placeholder="Enter Address" onChange={handleChange} /><br />
                                        <label className="form-label" for="address">Address</label>
                                    </div>


                                    <div className="form-outline mb-4">
                                        <input type="email" value={user.email} name="email" className="form-control-sm col-3" placeholder="Enter Email" onChange={handleChange} /><br />
                                        <label className="form-label" for="email">Email</label>
                                    </div>

                                    <div className="form-outline mb-4">
                                        <input type="password" name="password" className="form-control-sm col-3" placeholder="Enter Password" onChange={handleChange} /><br />
                                        <label className="form-label" for="password">Password</label>
                                    </div>

                                    <div className="d-flex justify-content-end pt-3">
                                        <button type="button" className="btn btn-light btn-lg">Reset all</button>
                                        <input type="submit" className="btn btn-warning btn-lg ms-2" name="submit" value="Update" />
                                    </div>
                                </form>
                            </div>
        
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}