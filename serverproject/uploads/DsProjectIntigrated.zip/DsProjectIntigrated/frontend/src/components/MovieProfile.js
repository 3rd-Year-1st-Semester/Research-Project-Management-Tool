//eslint-disable-line react-hooks/exhaustive-deps
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import '../styles/movie_profile.css'
import qrcode from 'qrcode';

const MovieProfile = () => {

    const params = useParams();

    const [data, setData] = useState([]);

    useEffect(() => {
        axios.get(`http://localhost:8000/movie/${params.id}`)
            .then((data) => {
                setData(data.data);
                console.log(data.data);

            })
            .catch((err) => {
                console.log(err);
            })
    }, []);

    //Qr code Generate part
    var qr = '';
    qrcode.toDataURL(`http://localhost:3000/addbooking/${params.id}`, ((err, url) => {
        if (err) {
            console.log(err);
        }
        qr = url;
    }))

    return (
        <div className='container'>
            <div className="container bg-white mt-3 mb-3">
                <h2>{data.movie_name}  ({data.year})</h2>
                <div className="row">
                    <div className="col-md-3 border-right">
                        <div className="d-flex flex-column align-items-center">
                            <img className="mt-5" width="250px" src={data.poster} />
                        </div>
                    </div>
                    <div className="col-md-1 border-right"></div>
                    <div className='col-md-4 border-right'>
                        <div className="d-flex flex-column">
                            <table className='mt-5 text-start'>
                                <tr>
                                    <td><b>Name               : </b></td>
                                    <td>{data.movie_name}</td>
                                </tr>
                                <tr>
                                    <td><b>Year               : </b></td>
                                    <td>{data.year}</td>
                                </tr>
                                <tr>
                                    <td><b>Category           : </b></td>
                                    <td>{data.movie_category}</td>
                                </tr>
                                <tr>
                                    <td><b>Lead Cast          : </b></td>
                                    <td>{data.lead_cast}</td>
                                </tr>
                                <tr>
                                    <td><b>Language           : </b></td>
                                    <td>{data.language}</td>
                                </tr>
                                <tr>
                                    <td><b>Ratings            : </b></td>
                                    <td>{data.ratings}</td>
                                </tr>
                                <tr>
                                    <td><b>Director           : </b></td>
                                    <td>{data.director_name}</td>
                                </tr>
                                <tr>
                                    <td><b>Released Date      : </b></td>
                                    <td>{data.released_date}</td>
                                </tr>
                                <tr>
                                    <td><b>Available Halls    : </b></td>
                                    <td>{data.available_halls}</td>
                                </tr>
                                <tr>
                                    <td colSpan="2"><br /></td>
                                </tr>
                                <tr>
                                    <td colSpan="2"><p style={{ textAlign: 'justify' }}><b>{data.description}</b></p></td>
                                </tr>
                                <tr>
                                    <td colSpan={2}>
                                        <a href={`/addbooking/0/Theater_not_selected/${params.id}`}><button className='btn btn-primary w-100 mb-2'>Book Now</button></a>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <div className="col-md-1 border-right"></div>
                    <div className="col-md-3 border-right">
                        <div className="d-flex flex-column align-items-center">
                            <h4 className='mt-5'>Scan the QR code for Booking</h4>
                            <img src={qr} width="250px" className='qr-img' />
                        </div>
                    </div>
                </div>
            </div>



        </div>
    );
}

export default MovieProfile;