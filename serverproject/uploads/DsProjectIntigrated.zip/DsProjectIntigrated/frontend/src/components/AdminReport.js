import { useState, useEffect } from "react"
import axios from 'axios'

export default function AdminReport() {

    const [users, setUsers] = useState([]);

    useEffect(() => {
        axios.get("/users/")
            .then((res) => {
                console.log(res.data);
                setUsers(res.data);
            })
            .catch((err) => {
                console.log(err);
            })
    }, []);

    const deleteMethod = (id) => {
        axios.delete(`/users/delete/${id}`)
            .then((data) => {
                alert(data.data)
            })
            .catch((err) => {
                console.log(err);
            })
    }

    return (

        <div class="container mt-5">
            <div className="c1 mt-5">
                
            <h3>User Registered Details Table</h3>

            <table class="table table-bordered mt-5">

                <thead>

                    <tr>
                        <th>Firstname</th>
                        <th>Lastname</th>
                        <th>Age</th>
                        <th>Phone Number</th>
                        <th>Address</th>
                        <th>Email</th>

                        <th>Delete</th>
                    </tr>

                </thead>
                <tbody>
                    {

                        users.map((val, key) => {

                            return (
                                <tr>
                                    <td>{val.first_name}</td>
                                    <td>{val.last_name}</td>
                                    <td>{val.age}</td>
                                    <td>{val.phone_number}</td>
                                    <td>{val.address}</td>
                                    <td>{val.email}</td>

                                    <td><a className="btn btn-danger" onClick={() => deleteMethod(val._id)}>Delete</a></td>
                                </tr>
                            )

                        })
                    }


                </tbody>
            </table>
        </div>
        </div>
        
    )
}

