import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

export default function MovieUpdate() {

    const { id } = useParams();

    const [data, setData] = useState([]);

    useEffect(() => {
        axios.get(`http://localhost:8000/movie/${id}`).then((res) => {
            setData(res.data);
            console.log(res.data);
        }).catch((err) => {
            console.log(err);
        })
    }, [])


    function updateMovie(event) {
        event.preventDefault();

        const formData = new FormData();

        formData.append('data', formData);

        axios.put(`http://localhost:8000/movie/update/${id}`, {
            method: "PUT",
            body: formData
        }).then(() => {
            alert("update Successfully");

        }).catch((err) => {
            console.log(err);
        })
        window.location.href = "/admin/movie";
    }

    const handleChange = event => {
        const { name, value } = event.target;
        setData({ ...data, [name]: value });
    }

    return (
        <div className="container">
            <center>
                <h1 className="text-light mt-5">Movie Update </h1>
                <form onSubmit={updateMovie} className="col-lg-4">
                    <div className="form-group">
                        <label>Movie Name</label>
                        <input type="text" name="movie_name" id="movie_name" value={data.movie_name} className="form-control" readOnly onChange={handleChange} />
                    </div>
                    <div className="form-group">
                        <label>movie_category</label>&nbsp;&nbsp;
                        <input type="text" name="movie_category" id="movie_category" value={data.movie_category} className="form-control" readOnly onChange={handleChange} />
                    </div>
                    <div className="form-group">
                        <label>Year</label>&nbsp;&nbsp;
                        <input type="text" name="year" id="year" value={data.year} className="form-control" onChange={handleChange} />
                    </div>
                    <div className="form-group">
                        <label>Ratings</label>&nbsp;&nbsp;
                        <input type="text" name="ratings" id="ratings" value={data.ratings} className="form-control" onChange={handleChange} />
                    </div>
                    <div className="form-group">
                        <label>Ratings</label>&nbsp;&nbsp;
                        <input type="file" name="poster" id="poster" value={data.poster} className="form-control" onChange={handleChange} />
                    </div>
                    <div className="form-group">
                        <label>Cast</label>&nbsp;&nbsp;
                        <input type="text" name="lead_cast" id="lead_cast" value={data.lead_cast} className="form-control" onChange={handleChange} />
                    </div>
                    <div className="form-group">
                        <label>Director</label>&nbsp;&nbsp;
                        <input type="text" name="director" id="director" value={data.director} className="form-control" onChange={handleChange} />
                    </div>
                    <div className="form-group">
                        <label>Language</label>&nbsp;&nbsp;
                        <input type="text" name="language" id="language" value={data.language} className="form-control" onChange={handleChange} />
                    </div>
                    <div className="form-group mt-3">
                        <input type="submit" name="submit" id="submit" value="Update" className="form-control btn btn-primary" />
                    </div>
                    <div className="form-group mt-3">
                        <input type="button" name="canncel" id="cancel" value="Cancel" className="form-control btn btn-danger" />
                    </div>


                </form>
            </center>
        </div>


    )

}