import React,{useState} from 'react';
import Paypal from './Paypal';

function Payment() {

    const [checkout,setCheckout] = useState(false);

    return (
        <div>
            {checkout ? (
                <Paypal/>
            ):(
            <button onClick={()=>{
                setCheckout(true)
            }}>Checkout</button>
            )}
        </div>
    );
}

export default Payment;