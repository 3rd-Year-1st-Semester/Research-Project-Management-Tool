import React, { useState } from 'react';
import axios from 'axios';

export default function AddTheater() {

    const [name, setName] = useState("");
    const [address, setAddress] = useState("");
    const [contact_no, setContact_no] = useState("");
    const [email, setEmail] = useState("");

    function sendData(e) {
        e.preventDefault();

        const newTheater = {
            name,
            address,
            contact_no,
            email,
        };
        console.log(newTheater);
        axios.post("http://localhost:8000/theater/add", newTheater).then(() => {
            alert("Theater Details Successfully Added !!!");
        }).catch((err) => {
            alert(err)
        });



    }





    return (
        <div>
            <div className="container">
                <form onSubmit={sendData}>
                    <div class="form-group">
                        <label for="name">Theater Name:</label>
                        <input type="text" class="form-control" id="name" placeholder="Enter Theater Name"
                            onChange={(e) => {
                                setName(e.target.value);
                            }} />

                    </div>

                    <div class="form-group">
                        <label for="address">Address:</label>
                        <input type="text" class="form-control" id="address" placeholder="Enter Address of the Theater Location"
                            onChange={(e) => {
                                setAddress(e.target.value);
                            }}
                        />

                    </div>

                    <div class="form-group">
                        <label for="contact_no">Theater Name:</label>
                        <input type="text " class="form-control" id="contact_no " placeholder="Enter Contact No"
                            onChange={(e) => {
                                setContact_no(e.target.value);
                            }}
                        />

                    </div>
                    <div class="form-group">
                        <label for="email">Email Address:</label>
                        <input type="email " class="form-control" id="email " placeholder="Enter Email Adress"
                            onChange={(e) => {
                                setEmail(e.target.value);
                            }}

                        />

                    </div>



                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    )
}  