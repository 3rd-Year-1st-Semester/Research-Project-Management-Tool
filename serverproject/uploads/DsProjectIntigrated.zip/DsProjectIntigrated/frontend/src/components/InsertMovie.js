import { useState } from 'react';
import FormData from 'form-data';

export const InsertMovie = () => {

    const [movie_name, setMovieName] = useState("");
    const [lead_cast, setLeadCast] = useState("");
    const [director_name, setDirectorName] = useState("");
    const [released_date, setReleasedDate] = useState("");
    const [ratings, setRatings] = useState("");
    const [language, setLanguage] = useState("");
    const [description, setDescription] = useState("");
    const [movie_category, setMovieCategory] = useState("");
    const [year, setYear] = useState("");
    const [available_halls, setAvailableHalls] = useState("");
    const [poster, setPoster] = useState("");

    const handleSubmit = async () => {
        try {

            let formData = new FormData();

            formData.append('movie_name', movie_name);
            formData.append('lead_cast', lead_cast);
            formData.append('director_name', director_name);
            formData.append('released_date', released_date);
            formData.append('ratings', ratings);
            formData.append('language', language);
            formData.append('description', description);
            formData.append('poster', poster);
            formData.append('movie_category', movie_category);
            formData.append('year', year);
            formData.append('available_halls', available_halls);

            const res = await fetch("http://localhost:8000/movie/insert", {
                method: "POST",
                body: formData
            });
            if (res.ok) {
                console.log("Movie added successfully");
            }
            else {
                console.log("Error");
            }

        }
        catch (err) {
            console.log(err);
        }

    }

    return (
        <div className="container">
            <div className='col-4 bg-warning p-2'>
                <h1>Insert New Movie</h1>
                <form onSubmit={handleSubmit}>
                    <div className='row'>
                        <div className='col'>
                            Movie Name : <input className='form-control col-sm-2' type="text" name="movie_name" onChange={(e) => {
                                setMovieName(e.target.value);
                                console.log(e.target.value);
                            }} />
                        </div>
                        <div className='col'>
                            Year : <input className='form-control' type="text" name="year" onChange={(e) => {
                                setYear(e.target.value)
                                console.log(e.target.value);
                            }} />
                        </div>
                    </div>
                    Lead Cast : <input className='form-control col-sm-2' type="text" name="lead_Cast" onChange={(e) => {
                        setLeadCast(e.target.value)
                        console.log(e.target.value);
                    }} />
                    <div className='row'>
                        <div className='col'>
                            Released Date : <input className='form-control' type="text" name="released_date" onChange={(e) => {
                                setReleasedDate(e.target.value)
                                console.log(e.target.value);
                            }} />
                        </div>
                        <div className='col'>
                            Ratings : <input className='form-control' type="text" name="ratings" onChange={(e) => {
                                setRatings(e.target.value)
                                console.log(e.target.value);
                            }} />
                        </div>
                    </div>
                    Director : <input className='form-control' type="text" name="director_name" onChange={(e) => {
                        setDirectorName(e.target.value)
                        console.log(e.target.value);
                    }} />
                    <div className='row'>
                        <div className='col'>
                            Language : <input className='form-control' type="text" name="language" onChange={(e) => {
                                setLanguage(e.target.value)
                                console.log(e.target.value);
                            }} />
                        </div>
                        <div className='col'>
                            Category : <input className='form-control' type="text" name="movie_category" onChange={(e) => {
                                setMovieCategory(e.target.value)
                                console.log(e.target.value);
                            }} />
                        </div>
                    </div>
                    Description : <input className='form-control' type="text" name="description" onChange={(e) => {
                        setDescription(e.target.value)
                        console.log(e.target.value);
                    }} />
                    Poster : <input className='form-control' type="file" name="poster" onChange={(e) => {
                        setPoster(e.target.files[0]);
                        console.log(e.target.files[0]);
                    }} />
                    Available Halls : <input className='form-control' type="text" name="available_halls" onChange={(e) => {
                        setAvailableHalls(e.target.value)
                        console.log(e.target.value);
                    }} /><br/>
                    <input type="submit" value="Insert Movie" className='form-control btn btn-primary' /><br/>
                </form>
            </div>
        </div>
    )
};

export default InsertMovie;