import React, { useState } from "react";
import axios from "axios";
import '../styles/signup.css';

export default function AdminRegister() {

    const [first_name, setFirst_Name] = useState('');
    const [last_name, setLast_Name] = useState('');
    const [age, setAge] = useState('');
    const [phone_number, setPhone_number] = useState('');
    const [address, setAddress] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const userData = {

        first_name, last_name, age, phone_number, address, email, password

    }
    //insert data
    const insertData = (e) => {

        e.preventDefault();
        axios.post("/admins/adminregister", userData).then((res) => {
            alert(res.data.status);
            console.log(res.data.status);

        }).catch((err) => {
            console.log(err);
        })

    }

    return (

        <div className="container py-5 h-100"style={{marginTop:"100px"}}>
        <div className="row d-flex justify-content-center align-items-center h-100">
            <div className="col">
                <div className="card card-registration my-4">
                    <div className="row g-0">
                        <div className="col-4 d-none d-xl-block">
                            <img src="https://th.bing.com/th/id/OIP.Tk4MyAoOxLOMFfIdSESInwHaLH?pid=ImgDet&rs=1"
                                className="img-fluid" alt="register_design"                               />
                        </div>
                        <div className="col">
                            <form onSubmit={insertData}>
                                <div className="card-body p-md-5 text-black">
                                    <h3 className="mb-5 text-uppercase"> Admin Sign Up</h3>

                                    <div className="row">
                                        <div className="col-md-6 mb-4">
                                            <div className="form-outline">
                                                <input type="text" name="first_name" id="first_name" className="form-control form-control-lg" onChange={(e) => {
                                                    setFirst_Name(e.target.value);
                                                }} />
                                                <label className="form-label" for="first_name">First name</label>
                                            </div>
                                        </div>
                                        <div className="col-md-6 mb-4">
                                            <div className="form-outline">
                                                <input type="text" name="last_name" id="last_name" className="form-control form-control-lg" onChange={(e) => {
                                                    setLast_Name(e.target.value);
                                                }} />
                                                <label className="form-label" for="last_name">Last name</label>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="row">
                                        <div className="col-md-6 mb-4">
                                            <div className="form-outline">
                                                <input type="text" name="age" id="age" className="form-control form-control-lg" onChange={(e) => {
                                                    setAge(e.target.value);
                                                }} />
                                                <label className="form-label" for="age">Age</label>
                                            </div>
                                        </div>
                                        <div className="col-md-6 mb-4">
                                            <div className="form-outline">
                                                <input type="text" name="phone_number" id="phone_number" className="form-control form-control-lg" onChange={(e) => {
                                                    setPhone_number(e.target.value);
                                                }} />
                                                <label className="form-label" for="phone_number">Phone Number</label>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="form-outline mb-4">
                                        <input type="text" name="address" id="address" className="form-control form-control-lg" onChange={(e) => {
                                            setAddress(e.target.value);
                                        }} />
                                        <label className="form-label" for="address">Address</label>
                                    </div>



                                    <div className="form-outline mb-4">
                                        <input type="email" name="email" id="email" className="form-control form-control-lg" onChange={(e) => {
                                            setEmail(e.target.value);
                                        }} />
                                        <label className="form-label" for="email">Email</label>
                                    </div>

                                    <div className="form-outline mb-4">
                                        <input type="password" name="password" id="password" className="form-control form-control-lg" onChange={(e) => {
                                            setPassword(e.target.value);
                                        }} />
                                        <label className="form-label" for="password">Password</label>
                                    </div>

                                    <div className="d-flex justify-content-end pt-3">
                                        <button type="button" className="btn btn-light btn-lg">Reset all</button>
                                        <input type="submit" className="btn btn-warning btn-lg ms-2" value="Submit form" />
                                    </div>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    )

}