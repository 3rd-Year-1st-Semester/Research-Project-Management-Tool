import React, { Component } from "react";
import axios from 'axios';
import { Link } from "react-router-dom";
 
const Record = (props) => (
  <tr>
    
    <td>{props.record._id}</td>
    <td>{props.record.name}</td>
    <td>{props.record.address}</td>
    <td>{props.record.contact_no}</td>
    <td>{props.record.email}</td>
    
    <td>
      <Link to={"/admin/update/" + props.record._id}>Edit</Link> |
      <a
        href="/admin"
        onClick={() => {
          props.deleteRecord(props.record._id);
         
        }}
      >
        Delete
      </a>
    </td>
  </tr>
);
 
export default class TheatersList extends Component {
  
  constructor(props) {
    super(props);
    this.deleteRecord = this.deleteRecord.bind(this);
    this.state = { records: [] };
  }
 
  
  componentDidMount() {
    axios
      .get("http://localhost:8000/theater/")
      .then((response) => {
        this.setState({ records: response.data });
      })
      .catch(function (error) {
        console.log(error);
      });
  }
 
  
  deleteRecord(id) {
    axios.delete("http://localhost:8000/theater/delete/" + id).then((response) => {
      console.log(response.data);
    });
 
    this.setState({
      record: this.state.records.filter((el) => el._id !== id),
    });
  }
 
  
  recordList() {
    return this.state.records.map((currentrecord) => {
      return (
        <Record
          record={currentrecord}
          deleteRecord={this.deleteRecord}
          key={currentrecord._id}
        />
      );
    });
  }


  render() {
    return (
      <div>
        <div>
        {/* <a class="btn btn-primary" href="/add" role="button">addproducts</a>
        <a class="btn btn-primary" href="/admin/viewUser" role="button">all users</a> */}
        
        </div>

        <br/><br/><br/><br/>
      <div className="container">
        
       <div><h3> Theater List</h3></div> 
        <table className="table table-striped" style={{ marginTop: 20 }}>
          <thead>
            <tr>
              
              
              <th>theaterid</th>
              <th>name</th>
              <th>address</th>
              <th>contact_no</th>
              <th>email</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>{this.recordList()}</tbody>
        </table>
      </div>
      </div>
    );
  }
}
