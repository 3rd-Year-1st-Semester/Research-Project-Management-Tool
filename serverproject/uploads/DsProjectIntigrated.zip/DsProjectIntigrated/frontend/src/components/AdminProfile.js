import React from 'react';
import jwt_decode from 'jwt-decode';
import axios from 'axios';
import '../styles/signin.css';

export default function AdminProfile() {

    const token = localStorage.usertoken;
    const decode = jwt_decode(token);

    const deleteMethod = (id) =>{
        axios.delete(`/users/delete/${id}`)
        .then((res)=>{
            alert(res.data)
            localStorage.removeItem("usertoken");
        })
        .catch((err)=>{
            console.log(err);
        })

    }
    return (

        <div className='container'>
            <center>
            <div className='card col-4 form-style p-3'>
                <div className='col-sm8  mx-auto  '>

                    <h3 className="text-center">Admin Profile</h3>
                </div>
                <table className="table col-md-6 mx-auto ">
                    <h5><center>
                        <tbody style={{textAlign:'left'}}>
                            <tr style={{tableLayout:'unset'}}>
                                <td>First Name </td>
                                <td>:  {decode.first_name}</td>
                            </tr>

                            <tr>
                                <td>Last Name</td>
                                <td>:  {decode.last_name}</td>
                            </tr>

                            <tr>
                                <td>Age</td>
                                <td>:  {decode.age}</td>
                            </tr>
                            <tr>
                                <td>Phone Number</td>
                                <td>:  {decode.phone_number}</td>
                            </tr>

                            <tr>
                                <td>Address</td>
                                <td>:  {decode.address}</td>
                            </tr>

                            <tr>
                                <td>Email</td>
                                <td>:  {decode.email}</td>
                            </tr>

                        </tbody>
                        </center>
                    </h5>
                </table>
                <center>
                <button className="btn btn-success mt-3 p-2"><a className='text-light' style={{textDecoration:'none'}} href={`/adminupdate/${decode._id}`}>Update</a></button>
                <button className="btn btn-danger mt-3 ml-4 p-2" onClick={()=>deleteMethod(decode._id)}>Delete</button>
                </center>
                



            </div>
            </center>
        </div>

    );


}



