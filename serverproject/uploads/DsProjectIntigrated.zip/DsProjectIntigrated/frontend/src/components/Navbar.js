import React, { Component } from 'react';
import { Link } from 'react-router-dom'

class Navbar extends Component {

  logOut(e) {
    e.preventDefault()
    localStorage.removeItem('usertoken');
    this.props.history.push('/')

  }

  render() {

    const loginRegLink = (

      <ul className='nav nav-tabs'>
        <li className='nav-item'>
          <Link to="/login" className="nav-link">
            <h6><img src="https://img.icons8.com/ios-filled/50/000000/login-rounded-right.png" />Login</h6>
          </Link>
        </li>

        <li className='nav nav-tabs'>
          <Link to="/register" className="nav-link">
            <h6><img src="https://img.icons8.com/external-flaticons-flat-flat-icons/64/000000/external-register-nursing-flaticons-flat-flat-icons.png" />Register</h6>
          </Link>

        </li>
      </ul>
    );

    const AdminloginRegLink = (

      <ul className='nav nav-tabs'>
        <li className='nav-item'>
          <Link to="/adminlogin" className="nav-link">
            <h6><img src="https://img.icons8.com/ios-filled/50/000000/login-rounded-right.png" />AdminLogin</h6>
          </Link>
        </li>

        <li className='nav nav-tabs'>
          <Link to="/adminregister" className="nav-link">
            <h6><img src="https://img.icons8.com/external-flaticons-flat-flat-icons/64/000000/external-register-nursing-flaticons-flat-flat-icons.png" />AdminRegister</h6>
          </Link>

        </li>
      </ul>
    );

    const UserLink = (

      <ul className='nav nav-tabs'>
        <li className='nav-item'>
          <Link to="/profile" className="nav-link">
            <h6><img src="https://img.icons8.com/office/16/000000/test-account.png" />User</h6>
          </Link>
        </li>

        <li className='nav nav-tabs'>
          <a href="" onClick={this.logOut.bind(this)} className="nav-link">
            <h6><img src="https://img.icons8.com/office/16/000000/logout-rounded.png" />Logout</h6>

          </a>
        </li>
      </ul>
    )
    const AdminLink = (

      <ul className='nav nav-tabs'>
        <li className='nav-item'>
          <Link to="/adminprofile" className="nav-link">
            <h6><img src="https://img.icons8.com/office/16/000000/test-account.png" />Admin</h6>
          </Link>
        </li>

        <li className='nav nav-tabs'>
          <a href="" onClick={this.logOut.bind(this)} className="nav-link">
            <h6><img src="https://img.icons8.com/office/16/000000/logout-rounded.png" />Logout</h6>

          </a>
        </li>
      </ul>
    )


    return (
      <div className='container mt-5'>
        <div className="container">
          <nav className="navbar navbar-expand-lg navbar-light rounded ">
            <button
              className="navbar-toggler"
              type="button"
              data-toggle="collapse"
              data-target="#navbar1"
              aria-controls="navbar1"
              aria-expanded="false"
              aria-label="Toggle navigation">

              <span className="navbar-toggler-icon"></span>
            </button>

            <div className="collapse navbar-collapse justify-content-md-center" id="navbar1">
              <ul className="nav nav-tabs" >
                <li classname="nav-item ">
                  <Link to="/" className="nav-link">

                    <h6><img src="https://img.icons8.com/pastel-glyph/64/000000/home.png" />Home</h6>

                  </Link>
                </li>
              </ul>
              {localStorage.userToken ? UserLink : loginRegLink}
              {localStorage.userToken ? AdminLink : AdminloginRegLink}
            </div>

          </nav>
        </div>
      </div>

    )


  }

}


export default Navbar;


