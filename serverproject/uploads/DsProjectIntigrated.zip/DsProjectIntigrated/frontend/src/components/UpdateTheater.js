// import React, { Component } from "react";
// import axios from 'axios';
// import { useNavigate, useParams } from "react-router-dom";


// export const withRouter = (WrappedComponent) => (props) => {
//   const params = useParams();
//   const navigate = useNavigate();

//   return <WrappedComponent {...props} params={params} navigate={navigate} />;
// };


//   class EditTheater extends Component {
  
//   constructor(props) {
//     super(props);
 
//     this.onChangename  = this.onChangename.bind(this);
   
//     this.onChangeaddress = this.onChangeaddressbind(this);
//     this.onChangecontact_number = this.onChangecontact_number.bind(this);
    
    
//     this.onChangeemail= this.onChangeemail.bind(this);
//     this.onSubmit = this.onSubmit.bind(this);
 
//     this.state = {
//         name: "",
//         address: "",
//         contact_number: "",
//         email: "",
//       records: [],
//     };
//   }
  
//   componentDidMount() {
    
//     axios
//       .get("http://localhost:8090/Theater/" +this.props.params.id)
//       .then((response) => {
//         this.setState({
//           name: response.data.name,
          
          
//           address: response.data.address,
//           contact_number: response.data.contact_number,
          
//           email: response.data.email,
//         });
//       })
//       .catch(function (error) {
//         console.log(error);
//       });
//   }
 
  
//   onChangename(e) {
//     this.setState({
//       name: e.target.value,
//     });
//   }
 
 
 
//   onChangeaddress(e) {
//     this.setState({
//       address: e.target.value,
//     });
//   }
//   onChangecontatc_number(e) {
//     this.setState({
//       contact_number: e.target.value,
//     });
//   }
 
//   onChangeemail(e) {
//     this.setState({
//       email: e.target.value,
//     });
//   }
 
  
//   onSubmit(e) {
//     e.preventDefault();
//     const newEditedTheater= {
//       name: this.state.name,
//       address: this.state.address,
//       contact_number: this.state.contact_number,
//       email: this.state.email,
//     };
//     console.log(newEditedTheater);
 
    
//     axios
//       .put(
//         "http://localhost:8000/Theater/" + this.props.params.id,
//         newEditedTheater
//       )
//       .then((res) => console.log(res.data));
      
 
//     //this.props.history.push("");
//   }
//   render() {
//     return (
//       <div>
          

// <br/><br/><br/><br/><br/>
//       <div className="container">
//         <h3 align="center">Update Theaterdetails</h3>
//         <form onSubmit={this.onSubmit}>
//           <div className="form-group">
//             <label>name: </label>
//             <input
//               type="text"
//               className="form-control"
//               value={this.state.name}
//               onChange={this.onChangename}
//             />
//           </div>
          
         
          
//           <div className="form-group">
//             <label>address: </label>
//             <input
//               type="Number"
//               className="form-control"
//               value={this.state.address}
//               onChange={this.onChangeaddress}
//             />
            
//           </div>
//           <div className="form-group">
//             <label>contact_number: </label>
//             <input
//               type="Number"
//               className="form-control"
//               value={this.state.contact_number}
//               onChange={this.onChangecontact_number}
//             />
            
//           </div>
          
//           <div className="form-group">
//             <label> email: </label>
//             <input
//               type="text"
//               className="form-control"
//               value={this.state.email}
//               onChange={this.onChangeemail}
//             />
            
//           </div>
          
//           <br />
 
//           <div className="form-group">
//             <input
//               type="submit"
//               value="Update Record"
//               className="btn btn-primary"
//             />
//           </div>
//         </form>
//       </div>
//       </div>
//     );
//   }


// }
// export default withRouter(EditTheater);