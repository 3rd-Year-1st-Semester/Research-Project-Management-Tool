import React, { useEffect, useState } from "react";
import axios from "axios";
import { useParams } from 'react-router-dom';


export default function AddBooking() {

    const { id } = useParams();
    const { name } = useParams();
    const { movieid } = useParams();

    const [userId, setuserId] = useState("");
    var [hallId, sethallId] = useState(id);
    const [movieId, setmovieId] = useState( movieid );
    const [seatNo, setseatNo] = useState("");
    const [totalPrice, settotalPrice] = useState();
    const [time, settime] = useState("");
    const [Date, setDate] = useState("");

    function sendData(e) {
        e.preventDefault();
        const newBooking = {
            userId,
            hallId,
            movieId,
            seatNo,
            totalPrice,
            time,
            Date,
        };
        console.log(newBooking);
        axios.post("http://localhost:8000/bookingdetails/add", newBooking).then(() => {
            alert("detail added");
        }).catch((err) => {
            alert(err);
        });
    }

    const [theater, settheaters] = useState([]);

    useEffect(() => {
        axios.get(`http://localhost:8000/theater/`)
            .then((theaters) => {
                settheaters(theaters.data);
                console.log(theaters.data);
            })
            .catch((err) => {
                console.error(err.message);
            });
    }, []);




    return (


        <div>
            <div><div className='container'>
                <h1 className='text-danger mt-5'>Booking Movies</h1><br />
                <div className="row row-cols-4 row-cols-md-4 g-4">
                    {theater.map((val, key) => {

                        return (
                            <div className="col  mb-5">
                                <div className="card text-start">

                                    <div className="card-body">
                                        <h5 className="card-title text-center">{val.name} </h5>

                                    </div>
                                    <a href={`/addbooking/${val._id}/${val.name}/${ movieid }`}><button className='btn btn-warning w-100'><b>Select Theater</b></button></a>
                                </div>
                            </div>
                        )
                    })}
                </div>

            </div>
            </div>



            <br /><br />
            <center><h5>{name}</h5></center>
            <br /><br />
            <center><h5>Fill the details</h5></center>
            <br />

            <div className="container">
                <form className="row g-3 needs-validation" novalidate onSubmit={sendData}>

                    <div className="col-md-4">
                        <label for="name" className="form-label">user id</label>
                        <input type="text" className="form-control " id="validationServer02" aria-describedby="inputGroupPrepend3 validationServerUsernameFeedback" required
                            onChange={(e) => {
                                setuserId(e.target.value);

                            }} />

                        <div className="valid-feedback">
                            Looks good!
                        </div>

                    </div>

                    <div className="col-md-4">
                        <label for="Date" className="form-label">Date</label>
                        <input type="date" className="form-control " id="validationServer02" aria-describedby="inputGroupPrepend3 validationServerUsernameFeedback" required
                            onChange={(e) => {
                                setDate(e.target.value);

                            }} />

                        <div className="valid-feedback">

                        </div>

                    </div>
                    {/* <div className="col-md-4">
                        <label for="cardholdername" className="form-label"></label>
                        <input type="text" className="form-control " id="validationServer02" aria-describedby="inputGroupPrepend3 validationServerUsernameFeedback" required hidden
                            onChange={(e) => {
                                sethallId(e.target.value);
                            }} />
                        <div id="validationServerUsernameFeedback" className="invalid-feedback">
                            Enter owner's name
                        </div>
                    </div> */}

                    <div className="col-md-6">
                        <label for="location" className="form-label">time</label>
                        <input type="time" className="form-control " id="validationServer03" aria-describedby="validationServer03Feedback" required
                            onChange={(e) => {
                                settime(e.target.value);

                            }} />

                        <div id="validationServer03Feedback" className="invalid-feedback">
                            Please provide a valid city.
                        </div>

                    </div>

                    <div className="col-md-3">
                        <label for="cvv" className="form-label">total pirice</label>
                        <input type="number" className="form-control " id="validationServer05" aria-describedby="validationServer05Feedback" required
                            onChange={(e) => {
                                settotalPrice(250*seatNo);

                            }} />

                        <div id="validationServer05Feedback" className="invalid-feedback">

                        </div>

                    </div>
                    <div className="col-md-3">
                        <label for="cvv" className="form-label">seat no</label>
                        <input type="number" className="form-control " id="validationServer05" aria-describedby="validationServer05Feedback" required
                            onChange={(e) => {
                                setseatNo(e.target.value);

                            }} />

                        <div id="validationServer05Feedback" className="invalid-feedback">

                        </div>

                    </div>
                    {/* <div className="col-md-4">
                        <label for="movieId" className="form-label">movie id</label>
                        <input type="text" className="form-control " id="validationServer02" aria-describedby="inputGroupPrepend3 validationServerUsernameFeedback" required
                            onChange={(e) => {
                                setmovieId(e.target.value);

                            }} />

                        <div className="valid-feedback">

                        </div>

                    </div> */}

                    <br />
                    <h3>total price = {250*seatNo}</h3>
                    <br />
                    <br />
                    <div className="col-12">
                        <button className="btn btn-primary" type="submit">book now</button>
                    </div>
                </form>
            </div>
        </div>
    );
}
