import React from 'react';
import { useState } from "react"
import axios from 'axios'
import '../styles/signin.css';

export default function Login() {

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const userData = {

        email, password

    }
    //insert data
    const UserLogin = (e) => {

        e.preventDefault();
        axios.post("/users/login", userData).then((res) => {

            if (res) {

                localStorage.setItem('usertoken', res.data);
                window.location.href = "/profile"
            }
            else {
                alert("Login failed");
            }

        }).catch((err) => {
            console.log(err);
        })

    }

    return (
        <div className='container text-center form-style'>
            <center>
                <form onSubmit={UserLogin}>
                    <img className="mb-3 mt-5" src="https://www.kindpng.com/picc/m/235-2350682_new-svg-image-small-user-login-icon-hd.png" alt="" width="100" height="100" />
                    <h1 className="h3 mb-3 font-weight-normal">Please sign in</h1>
                    <label for="inputEmail" className="sr-only">Email address</label>
                    <input type="email" id="inputEmail" className="form-control col-3" placeholder="Email address" required autofocus onChange={(e) => {
                            setEmail(e.target.value);
                        }}/>
                    <br></br>
                    <label for="inputPassword " className="sr-only">Password</label>
                    <input type="password" id="inputPassword" className="form-control col-3" placeholder="Password" required onChange={(e) => {
                            setPassword(e.target.value);
                        }}/>
                    <div className="checkbox mb-3">
                        <label>
                            <input type="checkbox" value="remember-me" /> Remember me
                        </label>
                    </div>
                    <button class="btn btn-lg btn-primary btn-block col-3" type="submit">Sign in</button>
                    
                </form>
            </center>
        </div>
    )

}