import React from 'react';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
//sachini
import Login from './components/Login'
import Register from './components/Register'
import Profile from './components/Profile'
import AdminLogin from './components/AdminLogin'
import AdminRegister from './components/AdminRegister'
import AdminProfile from './components/AdminProfile';
import AdminReport from './components/AdminReport';
import UserUpdate from './components/UserUpdate';
import AdminUpdate from './components/AdminUpdate';
import Header from './components/Header1';
import Footer from './components/Footer1';
//nipuna
import AddBooking from './components/AddBooking';
import BookingRecordList from './components/BookingAdmin';
import Header1 from './components/Header1';
import Footer1 from './components/Footer1';

//gayashan
import Movie from './components/Movie';
import MovieProfile from './components/MovieProfile';
import InsertMovie from './components/InsertMovie';
import Payment from './components/Payment';
import MovieManagement from './components/MovieManagement';
import MovieUpdate from './components/MovieUpdate';


import AddTheater from './components/AddTheater';
import ViewTheater from './components/ViewTheater';



const App = () => {

  return (


    <div className='App'>

      <Router>

        {/* <Navbar /> */}
        {/* <Header1 /> */}
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/adminlogin" element={<AdminLogin />} />
          <Route path="/adminregister" element={<AdminRegister />} />
          <Route path="/adminprofile" element={<AdminProfile />} />
          <Route path="/adminreport" element={<AdminReport />} />
          <Route path="/update/:id" element={<UserUpdate />} />
          <Route path="/adminupdate/:id" element={<AdminUpdate />} />


          <Route exact path="/addbooking/:id/:name/:movieid" element={<AddBooking />} />

          <Route exact path="/admin/booking" element={<BookingRecordList />} />


          <Route path='/' element={<Movie />}></Route>
          <Route path='/admin/movie' element={<MovieManagement />}></Route>
          <Route path='/profile/:id' element={<MovieProfile />} ></Route>
          <Route path='/insert' element={<InsertMovie />}></Route>
          <Route path='/payment' element={<Payment />}></Route>
          <Route path='/update/:id' element={<MovieUpdate />}></Route>


          <Route path="/addtheater"  element={<AddTheater/>} />

          <Route path="/viewtheater" element={<ViewTheater/>} />
          {/* <Route path="/" exact element={UpdateTheater} /> */}

        </Routes>
        {/* <Footer1 /> */}
      </Router>
    </div>
  )

}
export default App;
